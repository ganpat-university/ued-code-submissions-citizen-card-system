package Conectors;

import java.util.*;
import common.*;
import java.sql.*;
import com.*;
import java.io.*;

public class Credit extends Connect
{
    /////Function for connect to the MySQL Server Database////////////
	public Credit()
    {
		Connect.connect_mysql();
    }
	//////////Save User Details /////
	public String saveCredit(HashMap creditData)
	{
		String SQL = "INSERT INTO `credit` (`credit_applicant_id`, `credit_score`, `credit_description`) VALUES (?, ?, ?);";
		int record=0; 
		String error = "";
		
		try
		{
			pstmt = connection.prepareStatement(SQL);
			pstmt.setString(1,(String) creditData.get("credit_applicant_id"));
			pstmt.setString(2,(String) creditData.get("credit_score"));
			pstmt.setString(3,(String) creditData.get("credit_description"));
			
			record = pstmt.executeUpdate();
			pstmt.close();
			connection.close();
		}
		catch(Exception e)
		{
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			e.printStackTrace( printWriter );
			printWriter.flush();
			String stackTrace = writer.toString();
			error+="Error : "+stackTrace;
			System.out.println(" Error : "+ e.toString());
		}
		return error;
	}
	//////////////////Function for getting Users Details//////////	
    public HashMap getCreditDetails(int credit_id)
	{
        HashMap results = new HashMap();
        int count=0;
		try
		{
			String SQL = "SELECT * FROM `credit` WHERE credit_id = "+credit_id ;
            statement = connection.createStatement();
            rs = statement.executeQuery(SQL);
            while(rs.next())
			{
				results.put("credit_applicant_id",Integer.parseInt(rs.getString("credit_applicant_id")));
				results.put("credit_score",rs.getString("credit_score"));
				results.put("credit_description",rs.getString("credit_description"));
				count++;
            }
			if(count==0)
			{
				results.put("credit_applicant_id",0);
				results.put("credit_score","");
				results.put("credit_id","");
				results.put("credit_description","");
			}
         }
		 catch(Exception e)
		 {
            System.out.println("Error is: "+ e);
       	 }
        return results;
    }
    /// Update the Credit ////
	public String updateCredit(HashMap creditData)
	{
		String SQL = "UPDATE `credit` SET `credit_applicant_id` = ?, `credit_score` = ?, `credit_description` = ? WHERE `credit_id` = ?;";
		String error = "";
		
		int record=0;	
		
		try
		{
			pstmt = connection.prepareStatement(SQL);
			pstmt.setString(1,(String) creditData.get("credit_applicant_id"));
			pstmt.setString(2,(String) creditData.get("credit_score"));
			pstmt.setString(3,(String) creditData.get("credit_description"));
			pstmt.setString(4,(String) creditData.get("credit_id"));
			record = pstmt.executeUpdate();
			pstmt.close();
			connection.close();
		}
		catch(Exception e)
		{
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			e.printStackTrace( printWriter );
			printWriter.flush();
			String stackTrace = writer.toString();
			error+="Error : "+stackTrace;
			System.out.println(" Error : "+ e.toString());
		}
		return error;
	}
	
	////////////////Function for getting all the Airport Details////////////////////  
    public ArrayList getAllCredit(int type)
	{
		String SQL = "SELECT * FROM `credit`, `applicant` WHERE credit_applicant_id = applicant_id";
		if(type!=0)
			SQL = "SELECT * FROM `credit`, `applicant` WHERE credit_applicant_id = applicant_id AND applicant_id = "+type;
		int count=0;
        ArrayList resultArray = new ArrayList();
        try
		{
			statement = connection.createStatement();
            rs = statement.executeQuery(SQL);
            while(rs.next())
			{		
				HashMap results = new HashMap();
				results.put("credit_applicant_id",rs.getString("credit_applicant_id"));
				results.put("credit_score",rs.getString("credit_score"));
				results.put("credit_description",rs.getString("credit_description"));
				results.put("credit_id",rs.getString("credit_id"));	
				results.put("applicant_name",rs.getString("applicant_name"));
						
				count++;
                resultArray.add(results);
            }
         }
		catch(Exception e)
		{
            System.out.println("Error is: "+ e);
        }
        return resultArray;
    }
	/////Function for Getting the List////////////
	public String getApplicantOption(Integer SelID)
    {
		int selectedID = SelID.intValue();
    	return Connect.getOptionList("applicant","applicant_id","applicant_name","applicant_id,applicant_name",selectedID,"1");
    }
	/////Function for Getting the List////////////
	public String getCreditOption(Integer SelID)
    {
		int selectedID = SelID.intValue();
    	return Connect.getOptionList("type","type_id","type_name","type_id,type_name",selectedID,"1");
    }
}
