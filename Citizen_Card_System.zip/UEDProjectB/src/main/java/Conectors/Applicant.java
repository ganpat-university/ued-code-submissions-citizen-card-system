package Conectors;

import java.util.*;
import java.sql.*;
import common.*;
import java.io.*;

public class Applicant extends Connect
{
    /////Function for connect to the MySQL Server Database////////////
	public Applicant()
    {
		Connect.connect_mysql();
    }
	//////////Save User Details /////
	public String saveApplicant(HashMap applicantData)
	{
		String SQL = "INSERT INTO `applicant` (`applicant_name`, `applicant_mobile`, `applicant_email`, `applicant_password`, `applicant_address`, `applicant_city`, `applicant_state`, `applicant_pincode`, `applicant_passport_no`, `applicant_passport_city`, `applicant_passport_date`, `applicant_expiry_date`, `applicant_documents`, `applicant_tours`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
		int record=0; 
		String error = "";
		
		try
		{
			pstmt = connection.prepareStatement(SQL);
			pstmt.setString(1,(String) applicantData.get("applicant_name"));
			pstmt.setString(2,(String) applicantData.get("applicant_mobile"));
			pstmt.setString(3,(String) applicantData.get("applicant_email"));
			pstmt.setString(4,(String) applicantData.get("applicant_password"));
			pstmt.setString(5,(String) applicantData.get("applicant_address"));
			pstmt.setString(6,(String) applicantData.get("applicant_city"));
			pstmt.setString(7,(String) applicantData.get("applicant_state"));
			pstmt.setString(8,(String) applicantData.get("applicant_pincode"));
			pstmt.setString(9,(String) applicantData.get("applicant_passport_no"));
			pstmt.setString(10,(String) applicantData.get("applicant_passport_city"));
			pstmt.setString(11,(String) applicantData.get("applicant_passport_date"));
			pstmt.setString(12,(String) applicantData.get("applicant_expiry_date"));
			pstmt.setString(13,(String) applicantData.get("applicant_documents"));
			pstmt.setString(14,(String) applicantData.get("applicant_tours"));

			record = pstmt.executeUpdate();
			pstmt.close();
			connection.close();
		}
		catch(Exception e)
		{
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			e.printStackTrace( printWriter );
			printWriter.flush();
			String stackTrace = writer.toString();
			error+="Error : "+stackTrace;
			System.out.println(" Error : "+ e.toString());
		}
		return error;
	}
	//////////////////Function for getting Users Details//////////	
    public HashMap getApplicantDetails(int applicant_id)
	{
        HashMap results = new HashMap();
        int count=0;
		try
		{
			String SQL = "SELECT * FROM `applicant` WHERE applicant_id = "+applicant_id ;
            statement = connection.createStatement();
            rs = statement.executeQuery(SQL);
            while(rs.next())
			{
				results.put("applicant_name",rs.getString("applicant_name"));
				results.put("applicant_mobile",rs.getString("applicant_mobile"));
				results.put("applicant_email",rs.getString("applicant_email"));
				results.put("applicant_password",rs.getString("applicant_password"));
				results.put("applicant_address",rs.getString("applicant_address"));
				results.put("applicant_city",rs.getString("applicant_city"));
				results.put("applicant_state",Integer.parseInt(rs.getString("applicant_state")));
				results.put("applicant_pincode",rs.getString("applicant_pincode"));	
				results.put("applicant_id",rs.getString("applicant_id"));	
				results.put("applicant_passport_no",rs.getString("applicant_passport_no"));
				results.put("applicant_passport_city",rs.getString("applicant_passport_city"));
				results.put("applicant_passport_date",rs.getString("applicant_passport_date"));
				results.put("applicant_expiry_date",rs.getString("applicant_expiry_date"));
				results.put("applicant_documents",rs.getString("applicant_documents"));	
				results.put("applicant_tours",rs.getString("applicant_tours"));	

				count++;
            }
			if(count==0)
			{
				results.put("applicant_name","");
				results.put("applicant_mobile","");
				results.put("applicant_email","");
				results.put("applicant_password","");
				results.put("applicant_address","");
				results.put("applicant_city","");
				results.put("applicant_state",0);	
				results.put("applicant_pincode","");	
				results.put("applicant_id","");				
				results.put("applicant_passport_no","");
				results.put("applicant_passport_city","");
				results.put("applicant_passport_date","");
				results.put("applicant_expiry_date","");
				results.put("applicant_documents","");	
				results.put("applicant_tours","");	

			}
         }
		 catch(Exception e)
		 {
            System.out.println("Error is: "+ e);
       	 }
        return results;
    }
    /// Update the Applicant ////
	public String updateApplicant(HashMap applicantData)
	{
		String SQL = "UPDATE `applicant` SET `applicant_name` = ?, `applicant_mobile` = ?, `applicant_email` = ?, `applicant_password` = ?, `applicant_address` = ?, `applicant_city` = ?, `applicant_state` = ?, `applicant_pincode` = ?, `applicant_passport_no` = ?, `applicant_passport_city` = ?, `applicant_passport_date` = ?, `applicant_expiry_date` = ?, `applicant_documents` = ?, `applicant_tours` = ? WHERE `applicant_id` = ?;";
		String error = "";
		
		int record=0;	
		
		try
		{
			pstmt = connection.prepareStatement(SQL);
			pstmt.setString(1,(String) applicantData.get("applicant_name"));
			pstmt.setString(2,(String) applicantData.get("applicant_mobile"));
			pstmt.setString(3,(String) applicantData.get("applicant_email"));
			pstmt.setString(4,(String) applicantData.get("applicant_password"));
			pstmt.setString(5,(String) applicantData.get("applicant_address"));
			pstmt.setString(6,(String) applicantData.get("applicant_city"));
			pstmt.setString(7,(String) applicantData.get("applicant_state"));
			pstmt.setString(8,(String) applicantData.get("applicant_pincode"));
			pstmt.setString(9,(String) applicantData.get("applicant_passport_no"));
			pstmt.setString(10,(String) applicantData.get("applicant_passport_city"));
			pstmt.setString(11,(String) applicantData.get("applicant_passport_date"));
			pstmt.setString(12,(String) applicantData.get("applicant_expiry_date"));
			pstmt.setString(13,(String) applicantData.get("applicant_documents"));
			pstmt.setString(14,(String) applicantData.get("applicant_tours"));
			pstmt.setString(15,(String) applicantData.get("applicant_id"));
			record = pstmt.executeUpdate();
			pstmt.close();
			connection.close();
		}
		catch(Exception e)
		{
			StringWriter writer = new StringWriter();
			PrintWriter printWriter = new PrintWriter( writer );
			e.printStackTrace( printWriter );
			printWriter.flush();
			String stackTrace = writer.toString();
			error+="Error : "+stackTrace;
			System.out.println(" Error : "+ e.toString());
		}
		return error;
	}
	
	////////////////Function for getting all the Airport Details////////////////////  
    public ArrayList getAllApplicant()
	{
		String SQL = "SELECT * FROM `applicant`";
		int count=0;
        ArrayList resultArray = new ArrayList();
        try
		{
			statement = connection.createStatement();
            rs = statement.executeQuery(SQL);
            while(rs.next())
			{		
				HashMap results = new HashMap();
				results.put("applicant_name",rs.getString("applicant_name"));
				results.put("applicant_mobile",rs.getString("applicant_mobile"));
				results.put("applicant_email",rs.getString("applicant_email"));
				results.put("applicant_password",rs.getString("applicant_password"));
				results.put("applicant_address",rs.getString("applicant_address"));
				results.put("applicant_city",rs.getString("applicant_city"));
				results.put("applicant_state",Integer.parseInt(rs.getString("applicant_state")));
				results.put("applicant_pincode",rs.getString("applicant_pincode"));	
				results.put("applicant_id",rs.getString("applicant_id"));
				results.put("applicant_passport_no",rs.getString("applicant_passport_no"));
				results.put("applicant_passport_city",rs.getString("applicant_passport_city"));
				results.put("applicant_passport_date",rs.getString("applicant_passport_date"));
				results.put("applicant_expiry_date",rs.getString("applicant_expiry_date"));
				results.put("applicant_documents",rs.getString("applicant_documents"));	
				results.put("applicant_tours",rs.getString("applicant_tours"));		
						
				count++;
                resultArray.add(results);
            }
         }
		catch(Exception e)
		{
            System.out.println("Error is: "+ e);
        }
        return resultArray;
    }
	/////Function for Getting the List////////////
	public String getStateOption(Integer SelID)
    {
		int selectedID = SelID.intValue();
    	return Connect.getOptionList("state","state_id","state_name","state_id,state_name",selectedID,"1");
    }
    //////////////////Function for getting Login Details//////////	
    public HashMap getLoginDetails(String login_user,String login_password)
	{
        HashMap resultsArray = new HashMap();
        int count=0;
		try
		{
            String SQL =  "SELECT * FROM applicant WHERE applicant_email = '"+login_user+"' AND applicant_password = '"+login_password+"'" ;
            statement = connection.createStatement();
            rs = statement.executeQuery(SQL);
            while(rs.next())
			{
				resultsArray.put("applicant_id",rs.getString("applicant_id"));
				resultsArray.put("applicant_name",rs.getString("applicant_name"));
				resultsArray.put("login_level",4);
				count++;
            }
			if(count==0)
			{
				resultsArray.put("applicant_id","");
				resultsArray.put("applicant_name","");
				resultsArray.put("login_level",0);
			}
         }
		 catch(Exception e)
		 {
            System.out.println("Error is: "+ e);
       	 }
        return resultsArray;
    }	
    //////////////////Function for checking the existing username//////////	
    public int checkUsernameExits(String login_user, int type)
	{
        HashMap resultsArray = new HashMap();
        int exits=0;
		try
		{
			String SQL = "";
			if(type == 1) {
				SQL =  "SELECT * FROM applicant WHERE applicant_email = '"+login_user+"'" ;
			}
            statement = connection.createStatement();
            rs = statement.executeQuery(SQL);
            while(rs.next())
			{
				exits++;
            }
         }
		 catch(Exception e)
		 {
            System.out.println("Error is: "+ e);
       	 }
        return exits;
    }
    //////////////////Function for geting the Single Airport Details//////////	
    public boolean checkLogin(String login_user,String login_password)
	{
        int count=0;
		try
		{
            String SQL = "SELECT * FROM applicant WHERE applicant_email = '"+login_user+"' AND applicant_password = '"+login_password+"'" ;
            statement = connection.createStatement();
            rs = statement.executeQuery(SQL);
            while(rs.next())	count++;    
         }
		 catch(Exception e)
		 {
            System.out.println("Error is: "+ e);
       	 }
		if(count==0)
			return false;
        return true;
    }
}
