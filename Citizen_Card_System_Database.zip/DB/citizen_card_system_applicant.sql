-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: citizen_card_system
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `applicant`
--

DROP TABLE IF EXISTS `applicant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `applicant` (
  `applicant_id` int NOT NULL AUTO_INCREMENT,
  `applicant_name` varchar(255) NOT NULL,
  `applicant_mobile` varchar(255) NOT NULL,
  `applicant_email` varchar(255) NOT NULL,
  `applicant_password` varchar(255) NOT NULL,
  `applicant_address` varchar(255) NOT NULL,
  `applicant_city` varchar(255) NOT NULL,
  `applicant_state` varchar(255) NOT NULL,
  `applicant_pincode` varchar(255) NOT NULL,
  `applicant_passport_no` varchar(255) NOT NULL,
  `applicant_passport_city` varchar(255) NOT NULL,
  `applicant_passport_date` varchar(255) NOT NULL,
  `applicant_expiry_date` varchar(255) NOT NULL,
  `applicant_documents` text NOT NULL,
  `applicant_tours` text NOT NULL,
  PRIMARY KEY (`applicant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `applicant`
--

LOCK TABLES `applicant` WRITE;
/*!40000 ALTER TABLE `applicant` DISABLE KEYS */;
INSERT INTO `applicant` VALUES (1,'Vishal Raj','9876543212','vishalraj20@gnu.ac.in','aa','Allahabad','Mumbai','4','201301','dsf','asdf','adsf','asdf','asdf','asdf'),(2,'Kaushal Kishore','9183769868','kaushal.rahuljaiswal@gmail.com','aa','A : 42/6 Sector 62','vadodara','2','26101','jhhj','ghghjg','hjkhkj','hjgjh','gfghfq','bjjkhkj'),(3,'Amit','9876543212','rahul@gmail.com','aa','Allahabad','Test','3','Test','asf','asdf','asdf','asdf','asdf','asdf'),(4,'Aman Gupat','9878656545','aman.gupta@gmail.com','aa','Mumbai','Mumabi','5','234234','2d','2d','2d','2d','2d','2d'),(5,'Rahul Kumar','9862342342','rahul@gmail.com','aa','Pasco House','Delhi','1','122015','9','10','11','12','13','14'),(6,'Atul Kumar','8376986802','atul@gmail.com','aa','New Lahore Colony','New Delhi','1','110031','9','10','11','12','13','14'),(7,'Vishal','9409299279','zxxc474482@gmail.com','aa','D1-502','Vadodara','2','390021','2323212123','3432423dsf','dfsdfa','sdfadf','fsdafa','dgfad'),(8,'Avani','9409299275','avanigajjar20@gnu.ac.in','aa','puspak society','ahmadabad','2','390021','gjhjhjgj','jhgjkbhj','hjkhjkhjk','bhjjkgjk','none','none'),(9,'kamal','9409299279','vishalraj@gmail.com','aa','D1-502','Vadodara','2','390007','2323212123','3432423dsf','r324234','34223','dfsdf','gsfsd'),(10,'Vraj','8140254698','vrajpatel20@gnu.ac.in','aa','ghar me','ahmedabad','2','390021','1234567890','123456789','23456789','34567890','qwertgyjk','qawsdfrtgyhjikhyug');
/*!40000 ALTER TABLE `applicant` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-04 16:15:01
